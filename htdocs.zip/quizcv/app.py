from flask import Flask, render_template,request
from main import quiz
app=Flask(__name__)
@app.route("/")
def home():
    return "hello"
if __name__ == '__main__':
    quiz()
    app.run(debug=True )